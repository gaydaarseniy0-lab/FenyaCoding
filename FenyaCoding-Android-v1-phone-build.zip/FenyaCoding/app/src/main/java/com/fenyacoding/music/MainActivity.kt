package com.fenyacoding.music

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Ink = Color(0xFF0B0812)
private val Panel = Color(0xFF191326)
private val Panel2 = Color(0xFF241A35)
private val Purple = Color(0xFFB98AFF)
private val Muted = Color(0xFFAA9BBE)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { FenyaApp() }
    }
}

private enum class Tab(val label: String) {
    Home("Главная"), Search("Поиск"), Library("Библиотека"), Settings("Настройки")
}

@Composable
private fun FenyaApp() {
    var selected by remember { mutableStateOf(Tab.Home) }
    var isPlaying by remember { mutableStateOf(false) }

    MaterialTheme(
        colorScheme = darkColorScheme(
            background = Ink, surface = Panel, primary = Purple,
            onBackground = Color.White, onSurface = Color.White,
            secondary = Muted
        )
    ) {
        Scaffold(
            containerColor = Ink,
            bottomBar = {
                NavigationBar(containerColor = Panel, contentColor = Purple) {
                    Tab.entries.forEach { tab ->
                        val icon = when (tab) {
                            Tab.Home -> Icons.Filled.Home
                            Tab.Search -> Icons.Filled.Search
                            Tab.Library -> Icons.Filled.LibraryMusic
                            Tab.Settings -> Icons.Filled.Settings
                        }
                        NavigationBarItem(
                            selected = selected == tab,
                            onClick = { selected = tab },
                            icon = { Icon(icon, contentDescription = tab.label) },
                            label = { Text(tab.label, fontSize = 10.sp) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = Purple,
                                selectedTextColor = Purple,
                                indicatorColor = Panel2,
                                unselectedIconColor = Muted,
                                unselectedTextColor = Muted
                            )
                        )
                    }
                }
            }
        ) { padding ->
            Column(Modifier.fillMaxSize().padding(padding)) {
                when (selected) {
                    Tab.Home -> HomeScreen(isPlaying) { isPlaying = !isPlaying }
                    Tab.Search -> SearchScreen()
                    Tab.Library -> LibraryScreen()
                    Tab.Settings -> SettingsScreen()
                }
            }
        }
    }
}

@Composable
private fun Header() {
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 22.dp, vertical = 18.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column {
            Text("FenyaCoding", color = Purple, fontSize = 25.sp, fontWeight = FontWeight.ExtraBold)
            Text("YOUR MUSIC SPACE", color = Muted, fontSize = 10.sp, letterSpacing = 2.sp)
        }
        Surface(color = Panel2, shape = CircleShape) {
            Icon(Icons.Filled.Headphones, null, tint = Purple, modifier = Modifier.padding(12.dp))
        }
    }
}

@Composable
private fun HomeScreen(isPlaying: Boolean, onToggle: () -> Unit) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(bottom = 18.dp)
    ) {
        item { Header() }
        item {
            Column(Modifier.padding(horizontal = 18.dp)) {
                Box(
                    Modifier.fillMaxWidth()
                        .background(
                            Brush.linearGradient(listOf(Color(0xFF42236A), Color(0xFF171020))),
                            RoundedCornerShape(26.dp)
                        ).padding(22.dp)
                ) {
                    Column {
                        Text("GOOD EVENING", color = Purple, fontSize = 11.sp, letterSpacing = 2.sp)
                        Spacer(Modifier.height(10.dp))
                        Text("Твоя музыка.", color = Color.White, fontSize = 29.sp, fontWeight = FontWeight.Bold)
                        Text("Твои правила.", color = Purple, fontSize = 29.sp, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(8.dp))
                        Text("Твоё пространство для музыки", color = Muted, fontSize = 13.sp)
                    }
                }
                Spacer(Modifier.height(26.dp))
                Text("ТВОЯ МУЗЫКА", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(10.dp))
                EmptyCard(
                    icon = Icons.Filled.MusicNote,
                    title = "Пока здесь тихо",
                    description = "Источники музыки ещё не подключены. Позже здесь появятся твои треки и подборки."
                )
                Spacer(Modifier.height(22.dp))
                Text("СЕЙЧАС ИГРАЕТ", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(10.dp))
                PlayerCard(isPlaying, onToggle)
            }
        }
    }
}

@Composable
private fun PlayerCard(isPlaying: Boolean, onToggle: () -> Unit) {
    Column(
        Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(24.dp)).padding(17.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier.size(62.dp).background(
                    Brush.linearGradient(listOf(Color(0xFF9C5BDE), Color(0xFF321A50))),
                    RoundedCornerShape(15.dp)
                ),
                contentAlignment = Alignment.Center
            ) { Icon(Icons.Filled.GraphicEq, null, tint = Color.White, modifier = Modifier.size(32.dp)) }
            Spacer(Modifier.width(13.dp))
            Column(Modifier.weight(1f)) {
                Text(if (isPlaying) "Демо-плеер" else "Ничего не играет", fontWeight = FontWeight.Bold)
                Text(if (isPlaying) "Демонстрационный режим" else "Выбери источник музыки", color = Muted, fontSize = 12.sp)
            }
            IconButton(onClick = onToggle) {
                Icon(if (isPlaying) Icons.Filled.PauseCircle else Icons.Filled.PlayCircle,
                    contentDescription = "Воспроизведение", tint = Purple, modifier = Modifier.size(42.dp))
            }
        }
        Spacer(Modifier.height(15.dp))
        LinearProgressIndicator(
            progress = { if (isPlaying) 0.35f else 0f },
            modifier = Modifier.fillMaxWidth().height(4.dp),
            color = Purple,
            trackColor = Panel2
        )
        Spacer(Modifier.height(9.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("0:00", color = Muted, fontSize = 10.sp)
            Text("DEMO", color = Muted, fontSize = 10.sp)
        }
    }
}

@Composable
private fun SearchScreen() {
    Column(Modifier.fillMaxSize()) {
        Header()
        Text("Поиск", Modifier.padding(horizontal = 20.dp), fontSize = 27.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(16.dp))
        OutlinedTextField(
            value = "",
            onValueChange = {},
            modifier = Modifier.fillMaxWidth().padding(horizontal = 18.dp),
            enabled = false,
            placeholder = { Text("Поиск станет доступен после подключения источника") },
            leadingIcon = { Icon(Icons.Filled.Search, null) },
            shape = RoundedCornerShape(18.dp),
            colors = OutlinedTextFieldDefaults.colors(
                disabledBorderColor = Panel2,
                disabledTextColor = Color.White,
                disabledLeadingIconColor = Purple,
                disabledPlaceholderColor = Muted
            )
        )
        Spacer(Modifier.height(20.dp))
        EmptyCard(
            icon = Icons.Filled.CloudOff,
            title = "Источники не подключены",
            description = "На следующем этапе добавим подключение Spotify и SoundCloud."
        )
    }
}

@Composable
private fun LibraryScreen() {
    Column(Modifier.fillMaxSize()) {
        Header()
        Text("Библиотека", Modifier.padding(horizontal = 20.dp), fontSize = 27.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(16.dp))
        EmptyCard(
            icon = Icons.Filled.LibraryMusic,
            title = "Твоя библиотека пуста",
            description = "Избранное и плейлисты появятся после подключения музыкальных источников."
        )
    }
}

@Composable
private fun SettingsScreen() {
    var animations by remember { mutableStateOf(true) }
    var darkTheme by remember { mutableStateOf(true) }
    Column(Modifier.fillMaxSize()) {
        Header()
        Text("Настройки", Modifier.padding(horizontal = 20.dp), fontSize = 27.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(14.dp))
        SettingRow("Тёмная тема", "Фиолетовое оформление", darkTheme) { darkTheme = it }
        SettingRow("Анимации", "Плавные переходы интерфейса", animations) { animations = it }
        Spacer(Modifier.height(20.dp))
        Text("FenyaCoding 1.0.0", Modifier.align(Alignment.CenterHorizontally), color = Muted, fontSize = 12.sp)
    }
}

@Composable
private fun SettingRow(title: String, subtitle: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 6.dp)
            .background(Panel, RoundedCornerShape(18.dp)).padding(15.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Text(title, fontWeight = FontWeight.SemiBold)
            Text(subtitle, color = Muted, fontSize = 12.sp)
        }
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

@Composable
private fun EmptyCard(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    description: String
) {
    Column(
        Modifier.fillMaxWidth().padding(horizontal = 18.dp)
            .background(Panel, RoundedCornerShape(22.dp)).padding(22.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(icon, null, tint = Purple, modifier = Modifier.size(34.dp))
        Spacer(Modifier.height(10.dp))
        Text(title, color = Color.White, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(5.dp))
        Text(description, color = Muted, fontSize = 12.sp, lineHeight = 18.sp)
    }
}
